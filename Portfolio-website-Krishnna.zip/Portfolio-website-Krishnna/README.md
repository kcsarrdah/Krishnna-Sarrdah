This Is a Portfolio Website For Krishnna Sarrdah Built Using plain html and css.

 CSS:
 A seperate Css file called "Styles.css is used for the styling of the page."
 Another file called "Utilities.css" is used for storing some template styles like colors.

 Tags Used: 
 Link: to link external files,
 Head, Body, divs and section tags for the structure.

 css properties used:
 classes and id for selectors.
 @import for linking external sites.

Padding, margin, font family, flex, hover, borders, opacity

For smaller sizes, a js fuction is included to convert the navbar into a dropdown.

Other features used: 


